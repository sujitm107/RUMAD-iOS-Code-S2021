//
//  ViewController.swift
//  RUMADContactsApp
//
//  Created by Sujit Molleti on 3/2/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

