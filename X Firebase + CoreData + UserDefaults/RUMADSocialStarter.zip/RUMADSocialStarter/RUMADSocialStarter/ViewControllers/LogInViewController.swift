//
//  LogInViewController.swift
//  RUMADSocialStarter
//
//  Created by Sujit Molleti on 4/19/21.
//

import UIKit
import Firebase

class LogInViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    let LoginToSignUpSegue = "LoginToSignUp"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func validateFields() -> Bool{
        return true
    }

    @IBAction func LogInButtonTapped(_ sender: Any) {
        //Authenticate User using Firebase
        
        //Validate Text Fields
        let error = validateFields()

        if(error == false) {
            print("Error");
            
        } else {
            
            let email = emailTextField.text!
            let password = passwordTextField.text!
            
            
            //Signing in the user
            Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
                if(error != nil){
//                    self.showError(error!.localizedDescription)
                    print("Error")
                } else {
                    self.navigateToFeed()
                }
            }
            
            
        }
        
    }
    
    func navigateToFeed(){
        let feedViewController = storyboard?.instantiateViewController(identifier: "FeedViewController")
        view.window?.rootViewController = feedViewController
        view.window?.makeKeyAndVisible()
    }
    
    @IBAction func signUpButtonTapped(_ sender: Any) {
        
        performSegue(withIdentifier: LoginToSignUpSegue, sender: nil)
        
    }
    
}
