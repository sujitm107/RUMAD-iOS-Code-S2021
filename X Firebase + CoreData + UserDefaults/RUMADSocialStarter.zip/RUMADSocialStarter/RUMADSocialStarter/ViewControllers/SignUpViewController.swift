//
//  SignUpViewController.swift
//  RUMADSocialStarter
//
//  Created by Sujit Molleti on 4/19/21.
//

import UIKit
import Firebase

class SignUpViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        showError(passwordTextField as! DesignableTextField)
    }
    
    func showError(_ passwordTextField: DesignableTextField){
        
        passwordTextField.rightImage = UIImage(systemName: "xmark.octagon.fill")?.withTintColor(UIColor.red)
        
    }
    
    @IBAction func createAccountButtonTapped(_ sender: Any) {
        
        //Create an Account on Firebase
        let email = emailTextField.text!
        let password = passwordTextField.text!
        let username = usernameTextField.text!
        
        
        
        //Create the users
        Auth.auth().createUser(withEmail: email, password: password) { (result, err) in
            
            //Check for errors
            if err != nil  {
                //There was an error creating the user
                print("There was an Error")
            } else {
                //User was created successfully, now store the first name and last name
                let db = Firestore.firestore()
                
                //result generates a uid
                db.collection("users").addDocument(data: ["username": username, "uid": result!.user.uid]) { (error) in
                    if error != nil {
                        //Show error message
                        print("Error saving user data")
                    }
                }
                
                //Transition to the home screen
                self.transitionToFeed()
                
            }
        }
        
        
        
        
    }
    
    func transitionToFeed(){
        let feedViewController = storyboard?.instantiateViewController(withIdentifier: "FeedViewController")
        self.view.window?.rootViewController = feedViewController
        self.view.window?.makeKeyAndVisible()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
