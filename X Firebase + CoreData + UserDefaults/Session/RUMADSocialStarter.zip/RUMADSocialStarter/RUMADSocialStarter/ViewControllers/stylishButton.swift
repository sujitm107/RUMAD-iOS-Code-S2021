//
//  stylishButton.swift
//  RUMADSocialStarter
//
//  Created by Sujit Molleti on 4/20/21.
//

import UIKit

class stylishButton: UIButton {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    override func draw(_ rect: CGRect) {
        self.layer.cornerRadius = 10
        self.layer.backgroundColor = CGColor(UIColor.systemBlue)
        self.layer.
    }

}
