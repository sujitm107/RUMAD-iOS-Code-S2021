//
//  SignUpViewController.swift
//  RUMADSocialStarter
//
//  Created by Sujit Molleti on 4/19/21.
//

import UIKit
//DON'T FORGET TO IMPORT FIREBASE
import Firebase

class SignUpViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func validateFields() -> Bool{
        
        if usernameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return true
        }
        
        return false
        
    }
    
    @IBAction func createAccountButtonTapped(_ sender: Any) {
        
        //USE FIREBASE HERE!!! Create an Account on Firebase
        let errorsPresent = validateFields()
        
        if errorsPresent {
            print("Error with user input")
            return
        }
        
        let username = usernameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        Auth.auth().createUser(withEmail: email!, password: password!) { (result, error) in
            
            if error != nil {
                print("There was an error in creating the user")
                print(error)
            } else{
                
                let db = Firestore.firestore()
                
                db.collection("users").addDocument(data: ["username" : username, "uid": result!.user.uid]) { (error) in
                    if error != nil {
                        print("Not able to save data")
                    } else {
                        print("Successfully saved user data in users collection")
                    }
                    
                }
                
                print("Successfully created the user")
                self.navigateToFeed()
                
            }
            
            
        }
        
        
        
        
        
        
    }
    
    func navigateToFeed() {
        let feedViewController = storyboard?.instantiateViewController(withIdentifier: "FeedViewController")
        self.view.window?.rootViewController = feedViewController
        self.view.window?.makeKeyAndVisible()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
